static const char screensaver_id[] =
	"@(#)xscreensaver 5.36 (10-Oct-2016), by Jamie Zawinski (jwz@jwz.org)";
